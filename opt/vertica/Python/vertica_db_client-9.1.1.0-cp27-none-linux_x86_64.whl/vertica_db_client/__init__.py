#
# __init__.py - initialization module for vertica-db-client
#
# Copyright (c) 2007 EntIT Software LLC, a Micro Focus company
# 
# Creation Date: January 5, 2015
#

#
# Import things here that need to be visible after "import vertica_db_client [as whatever]".
#
from vertica_db_client import v_connect, Error, Warning, ProgrammingError, InterfaceError, InternalError, DatabaseError, IntegrityError, OperationalError, DataError, NotSupportedError, apilevel, threadsafety, paramstyle, connection, cursor

from dbapi_types import Binary as Binary
from dbapi_types import Date as Date
from dbapi_types import Time as Time
from dbapi_types import Timestamp as Timestamp
from dbapi_types import DateFromTicks as DateFromTicks
from dbapi_types import TimeFromTicks as TimeFromTicks
from dbapi_types import TimestampFromTicks as TimestampFromTicks

#
# Things that are visible after "from vertica_db_client import *"
#
__all__=["connect","Warning","Error","ProgrammingError","InterfaceError","InternalError","DatabaseError","IntegrityError","OperationalError","DataError","NotSupportedError"]

import re
import sys

if sys.version_info.major != 2 or sys.version_info.minor != 7:
    raise RuntimeError('vertica_db_client is only supported with Python 2.7')

def v_escape_param(s,
        re_escape=re.compile(r"([\\'])"),
        re_space=re.compile(r'\s')):
    """
    Apply the escaping rule required by PQconnectdb.
    """
    if not s:
        return "''"

    s = re_escape.sub(r'\\\1', s)
    if re_space.search(s):
        s = "'{}'".format(s)

    return s

def connect(dsn=None, database=None, user=None, password=None, host=None,
            port=None, sslmode=None, sessionlabel=None, connsettings=None):
    """Returns a new database connection object.

    Args:
        dsn (Optional[str]): Data Source Name (DSN) is the ODBC logical name for the drive 
            and other information the database needs to access data.

        database (str): The name of your Vertica database.

        user (str): Your Vertica user name.

        password (str): The password for the user's account.

        host (Optional[str]): The name of the host.

        port (Optional[str]): The port number on which Vertica listens for ODBC connections. Default value: 5433

        sslmode (Optional[str]): Specifies how (or whether) clients use SSL when connecting to servers. 
            The default value is prefer, meaning to use SSL if the server offers it. Legal values are 
            "require", "prefer", "allow", and "disable".

        sessionlabel (Optional[str]): Sets a label for the connection on the server. This value appears in the 
            session_id column of the V_MONITOR.SESSIONS system table.

        connsettings (Optional[str]): A string containing SQL commands that the driver should execute immediately 
            after connecting to the server. You can use this parameter to configure the connection, 
            such as setting a schema search path. Reserved symbols: In the connection string ';' 
            is a reserved symbol. To set multiple parameters as part of ConnSettings parameters, use '%3B' 
            for ','. Also use '+' for spaces.

    Examples:
        As a connection string::

            conn = vertica_db_client.connect("database=verticadb user=user_name password=pwd")

        As a set of keyword arguments::

            conn = vertica_db_client.connect(database="verticadb", user='user_name', password='pwd')

        As a dictionary::

            dict_conn = {'database': 'verticadb', 'user': 'user_name', 'password': 'pwd'}
            conn = vertica_db_client.connect(dict_conn)
    """

    # No matter how we get its content, this string is what
    # gets passed to connect().
    conn_str = ""

    # Capture keyword args in a key/value list
    properties = []
    if database is not None:
        properties.append(('dbname', database))
    if user is not None:
        properties.append(('user', user))
    if password is not None:
        properties.append(('password', password))
    if host is not None:
        properties.append(('host', host))
    if port is not None:
        properties.append(('port', port))
    if connsettings is not None:
        properties.append(('connsettings', connsettings))
    if sslmode is not None:
        properties.append(('sslmode', sslmode))
    if sessionlabel is not None:
        properties.append(('sessionlabel', sessionlabel))

    # Validate the combination of arguments. If dsn is specified, 
    # nothing else can be.
    if dsn is not None and len(properties) > 0:
        raise ValueError("'%s' is an invalid keyword argument when dsn is specified" % properties[0][0])

    if dsn is None:
        if not properties:
            raise ValueError('dsn or other connection properties must be specified')
        else:
             conn_str = " ".join(["%s=%s" % (k, v_escape_param(str(v)))
                for (k, v) in properties])
             conn_str = conn_str.rstrip(' ')
    elif type(dsn) is dict:
        conn_str = "".join(["{}={} ".format(k,v_escape_param(v)) for k,v in dsn.iteritems()])
        conn_str = conn_str.rstrip(' ')
    elif type(dsn) is bytes:
        conn_str = dsn
    else:
        raise TypeError('dsn is not a supported type (must be dict or str)')

    conn_str = re.sub('database=','dbname=',conn_str)

    conn = v_connect(conn_str)

    return conn
